
@extends('layout_admin')
@section('title','Dashboard' )
@section('content')
<div>Some Content . . .</div>
@endsection

